
This is just a haphazard collection of code examples for a d3.js book.
